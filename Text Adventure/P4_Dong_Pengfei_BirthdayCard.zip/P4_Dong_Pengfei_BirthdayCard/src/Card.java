import java.io.File;
import java.io.FileInputStream;

import javafx.animation.FadeTransition;
import javafx.animation.PathTransition;
import javafx.animation.PauseTransition;
import javafx.animation.SequentialTransition;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.shape.CubicCurve;
import javafx.scene.shape.Line;
import javafx.scene.shape.QuadCurve;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import javafx.util.Duration;

public class Card extends Application {

	public static void main(String[] args) {
		
		launch(args);
		
	}
	
	@Override
	public void start(Stage stage) throws Exception {
		
		stage.setTitle("Card");
		stage.setResizable(false);
		stage.sizeToScene();
		
		Group root = new Group();
		Scene scene = new Scene(root, 1280, 800);
		stage.setScene(scene);
		
		String musicFile = "HappyBirthday.mp3";

		Media sound = new Media(new File(musicFile).toURI().toString());
		MediaPlayer mediaPlayer = new MediaPlayer(sound);		
		
		//stylesheet and "happy birthday text"
		scene.getStylesheets().add("https://fonts.googleapis.com/css?family=Forum");
		
		Text text = new Text( "Blow out the Candles!" );
		text.setStyle("-fx-font-family: Forum; -fx-font-size: 80;");
		text.setFill( Color.rgb(0, 255, 255) );
		
		Text HBD = new Text("Happy Birthday, [Redacted]!");
		HBD.setStyle("-fx-font-family: Forum; -fx-font-size: 80;");
		HBD.setFill( Color.rgb(255, 255, 0) );
		HBD.setX(200);
		HBD.setY(600);
		HBD.setOpacity(0);
		
		// images
		FileInputStream inputstream = new FileInputStream("balloon.png"); 
		Image image = new Image(inputstream);
		
		ImageView balloon1 = new ImageView( image );
		balloon1.setFitWidth(150);
        balloon1.setPreserveRatio(true);
        
        ImageView balloon2 = new ImageView(image);
        balloon2.setFitWidth(150);
        balloon2.setPreserveRatio(true);

		inputstream = new FileInputStream("balloonV2.png");
		image = new Image(inputstream);
        
        ImageView balloon3 = new ImageView(image);
        balloon3.setFitWidth(150);
        balloon3.setPreserveRatio(true);
        
        ImageView balloon4 = new ImageView(image);
        balloon4.setFitWidth(150);
        balloon4.setPreserveRatio(true);
				
        inputstream = new FileInputStream("cake.png");
		image = new Image(inputstream);
		
		ImageView cake = new ImageView(image);
		cake.setPreserveRatio(true);
        
		inputstream = new FileInputStream("room.jpg");
		image = new Image(inputstream);
		
		ImageView room = new ImageView(image);
		room.setFitHeight(800);

		inputstream = new FileInputStream("cannon.png");
		image = new Image(inputstream);
		
		ImageView cannonL = new ImageView(image);
		cannonL.setX(23042);

		inputstream = new FileInputStream("cannon2.png");
		image = new Image(inputstream);
		
		ImageView cannonR = new ImageView(image);
        cannonR.setPreserveRatio(true);
		cannonR.setX(23042);

        
        inputstream = new FileInputStream("confetti.png");
        image = new Image(inputstream);
        
        ImageView confettiR = new ImageView(image);
        confettiR.setFitWidth(200);
        confettiR.setPreserveRatio(true);
        
        ImageView confettiL = new ImageView(image);
        confettiL.setFitWidth(200);
        confettiL.setPreserveRatio(true);
        
        // paths for images
		CubicCurve balloon1Path = new CubicCurve(100,900, 200, 600, 0, 400, 200, 150);
		balloon1Path.setStrokeWidth(5);
		balloon1Path.setStroke( Color.rgb(0,0,0) );
		balloon1Path.setFill(null);
		balloon1Path.setOpacity(0);
		
		CubicCurve balloon2Path = new CubicCurve(400, 900, 500, 600, 300, 400, 100, 150);
		balloon2Path.setStrokeWidth(5);
		balloon2Path.setStroke( Color.rgb(0, 0, 0) );
		balloon2Path.setFill(null);
		balloon2Path.setOpacity(0);
		
		CubicCurve balloon3Path = new CubicCurve(200, 1000, 400, 700, 100, 500, 350, 250);
		balloon3Path.setStrokeWidth(5);
		balloon3Path.setStroke( Color.rgb(0, 0, 0) );
		balloon3Path.setFill(null);
		balloon3Path.setOpacity(0);
		
		CubicCurve balloon4Path = new CubicCurve(300, 900, 700, 600, 500, 400, 250, 200);
		balloon4Path.setStrokeWidth(5);
		balloon4Path.setStroke( Color.rgb(0, 0, 0) );
		balloon4Path.setFill(null);
		balloon4Path.setOpacity(0);
		
		Line line = new Line(scene.getWidth()/2-cake.getFitWidth(),scene.getHeight()+100,scene.getWidth()/2-cake.getFitWidth(),scene.getHeight()/2);
		line.setOpacity(0);
		
		QuadCurve confettiLineL = new QuadCurve( -200, 800, 500, 0, 650, 1000 );
		confettiLineL.setFill(null);
		confettiLineL.setStroke( Color.rgb(0, 0, 0) );
		confettiLineL.setOpacity(0);
		
		QuadCurve confettiLineR = new QuadCurve( scene.getWidth()+200, 800, scene.getWidth()-500, 0, scene.getWidth()-650, 1000 );
		confettiLineR.setFill(null);
		confettiLineR.setStroke( Color.rgb(0, 0, 0) );
		confettiLineR.setOpacity(0);

		
		Line cannonLineL = new Line( -1*scene.getWidth()/2, scene.getHeight()*3/2, 300, scene.getHeight()/2  );
		cannonLineL.setOpacity(0);
		
		Line cannonLineR = new Line( scene.getWidth()*3/2, scene.getHeight()*3/2, scene.getWidth()-300, scene.getHeight()/2 );
		cannonLineR.setOpacity(0);
		
		Line cannonRecoilLineL = new Line( 300, scene.getHeight()/2,250, scene.getHeight()/2+50 );
		Line cannonRecoilLineR = new Line( scene.getWidth()-300, scene.getHeight()/2, scene.getWidth()-250, scene.getHeight()/2+50 );
		cannonRecoilLineL.setOpacity(0);
		cannonRecoilLineR.setOpacity(0);
		
		Line textLine = new Line( scene.getWidth()/2, -300, scene.getWidth()/2, 600 );
		textLine.setOpacity(0);
		
		//transitions
		PauseTransition secondTenOne = new PauseTransition( new Duration(10000) );
		PauseTransition secondTenTwo = new PauseTransition( new Duration(10000) );
		PauseTransition secondSixteen = new PauseTransition( new Duration(16000) );
		
		SequentialTransition groupTrans = new SequentialTransition();
		SequentialTransition confettiSync = new SequentialTransition();
		SequentialTransition cannonRecoilLSync = new SequentialTransition();
		SequentialTransition cannonRecoilRSync = new SequentialTransition();
		
		PathTransition path1 = new PathTransition ( new Duration(4000), balloon1Path, balloon1 );
		PathTransition path2 = new PathTransition ( new Duration(4000), balloon2Path, balloon2 );
		PathTransition path3 = new PathTransition ( new Duration(4000), balloon3Path, balloon3 );
		PathTransition path4 = new PathTransition ( new Duration(4000), balloon4Path, balloon4 );
		PathTransition cakePath = new PathTransition( new Duration(4000), line, cake );
		
		PathTransition confettiPathL = new PathTransition ( new Duration(2000), confettiLineL,confettiL );
		PathTransition confettiPathR = new PathTransition ( new Duration(2000), confettiLineR,confettiR );
		
		PathTransition cannonLPath = new PathTransition( new Duration(2000), cannonLineL, cannonL );
		PathTransition cannonRPath = new PathTransition( new Duration(2000), cannonLineR, cannonR );
		
		PathTransition cannonLRecoil = new PathTransition( new Duration(1000), cannonRecoilLineL, cannonL );
		cannonLRecoil.setCycleCount(2);
		cannonLRecoil.setAutoReverse(true);
		
		PathTransition cannonRRecoil = new PathTransition( new Duration(1000), cannonRecoilLineR, cannonR );
		cannonRRecoil.setCycleCount(2);
		cannonRRecoil.setAutoReverse(true);
		
		PathTransition textPath = new PathTransition( new Duration(6000), textLine, text );
		
		FadeTransition cannonFadeOutL = new FadeTransition( new Duration(1), cannonL );
		cannonFadeOutL.setToValue(0);
		FadeTransition cannonFadeOutR = new FadeTransition( new Duration(1), cannonR );
		cannonFadeOutR.setToValue(0);
		
		FadeTransition cannonFadeInL = new FadeTransition( new Duration(1), cannonL );
		cannonFadeInL.setToValue(1.0);
		FadeTransition cannonFadeInR = new FadeTransition( new Duration(1), cannonR );
		cannonFadeInR.setToValue(1.0);

		FadeTransition textFade = new FadeTransition( new Duration(2000), text );
		textFade.setToValue(0);
		
		FadeTransition HBDFadeIn = new FadeTransition( new Duration(4000), HBD);
		HBDFadeIn.setToValue(1);
		
		SequentialTransition textMovement = new SequentialTransition();
		SequentialTransition textMovementA = new SequentialTransition();
		
		PauseTransition pause = new PauseTransition( new Duration(4000) );
		PauseTransition secondEight = new PauseTransition( new Duration(8000) );
		
		root.getChildren().addAll( room, balloon1Path, balloon2Path, balloon3Path, balloon4Path, balloon1, balloon2, balloon3, balloon4, line, cake,
									cannonL, cannonLineL, cannonR, cannonLineR, confettiLineR, confettiLineL, confettiL, confettiR,
									cannonRecoilLineL, cannonRecoilLineR, text, textLine, HBD);
		
		stage.show();
		
		cannonRecoilLSync.getChildren().addAll( cannonFadeOutL, secondTenOne, cannonLRecoil );
		cannonRecoilRSync.getChildren().addAll( cannonFadeOutR, secondTenTwo, cannonRRecoil );
		groupTrans.getChildren().addAll(pause, cakePath, cannonFadeInL, cannonLPath, confettiPathL);	
		confettiSync.getChildren().addAll( secondEight, cannonFadeInR, cannonRPath, confettiPathR );
		textMovement.getChildren().addAll( secondTenOne, textPath, textFade );
		textMovementA.getChildren().addAll( secondSixteen, HBDFadeIn );
		
		path1.play();
		path2.play();
		path3.play();
		path4.play();
		
		groupTrans.play();
		mediaPlayer.play();
		confettiSync.play();
		cannonRecoilLSync.play();
		cannonRecoilRSync.play();
		textMovement.play();
		textMovementA.play();
		
	}

}





























